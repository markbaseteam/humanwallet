# 3 - Encounter with a robot
◀ [[2 - Kagu is worried]]
No sign of doctor Burns, he was all by himself. Or wasn’t he?

He felt like a minor tremor in his neck, a feeling that had always warned him he was being watched. He looked around him, scanned the whole room, which was clinically white wherever he looked. But there wasn’t a single hiding place. The only furniture was the table he had been lying on and a small cabinet on the side of it. Next to the door, a wardrobe – “that’s it, Denter, no further ghosts, specters or phantoms – that kind of money is making you jumpy, so it seems” – so he turned back to the table.

“The amount of money seems to be making you nervous, 25B36?”

Denter couldn’t help himself, jump turned, and couldn’t believe a young woman was standing next to the wardrobe. The same wardrobe he scanned 3 seconds ago.

But it was the feeling that she could read his mind that gave him the creeps.

“Who are you?”

“Xe4S, serial GH397, but I’d prefer you’d call me Margo. I’m your protection for this assignment”.

“OK, Margo, not sure if I’m all that pleased to meet you”.

“Guess you shouldn’t be, guess my presence makes you nervous, but rest assured that I will do everything within my power to get you out of this assignment alive - only to never have to meet you again”.

“Since this appears to be our last encounter, could you please tell me how you got in here? I found your sudden appearance slightly spooky, to be honest.

“There’s no time for that, Liam, we must move. We have a cab reservation in just 6 minutes”.

“But I still want to know how you got into that room without me noticing”.

“Elevator B-5”.

Very clearly, Margo wasn’t in the mood for small talk. Without a word, she dragged him into elevator M-3.

“What’s this all about?? “B-5”, you said”. And that was pretty painful, that vice you’re putting on my wrist.

“Sorry to appear unkind, but grabbing and squeezing your wrist was my only chance to alter your tracking device, which is now sending a fake signal and we cannot be overheard anymore either. I overruled the programming of the elevators because there are no working cameras in this one. So, most probably, authorities have lost track of you now. The cab that is collecting us, is not an official one and it will not be coming to the front of the building, but a bit further down the road, at the back”.

“Huh??”

“I’ve done my research. You may have had your share of dangerous assignments, but they all look like a day at the kindergarten compared to this one, believe me. So, bear with me for a moment until we’re in the underground cab. You carry an awful lot of money with you and there are loads of people who are after that, most of them you wouldn’t expect to have criminal fantasies. But most of all, Jaxon Reyes will prefer to waste you once he’s laid his hands on the cash”.

“My client will want his receipt, so that would be a very big risk”.

“No, it wouldn’t. Now, let’s get the hell out of here. No, not through the main exit, take the East 43 Exit. You go first, so I can check if somebody tries to tail you. Don’t run, walk normally, don’t look back. Turn right once you’ve left the building and left at the first crossing. You’ll see a grey cab parked under the first tree. Get in it, I’m right behind you”.

“And…”

“Shut up and move”.

Under the first tree, there wasn’t a cab. Liam was already turning his head when it arrived as if it had been waiting for him to arrive. It parked under the tree and opened its door. A subtle push in his back made him step inside. Margo was, like she said earlier, right behind him. She had a quick look around, stepped in, and closed the door. The cab took off and all of the windows went completely black. Liam couldn’t help himself to admire the professionalism and timing. In this timespan (of what – 10, 12 minutes?), he had been surprised 5 or 6 times. He had, indeed, had his share of risky assignments, but this Margo was just another league.

For the first time they met, he looked at her a little closer. Handsome, but without catching the eye, a very clearly well-trained body, short brown hair, and, most intriguing, yellowish, almost golden eyes.

[[4 - Going down some levels]]
