# 4 - Going down some levels
◀ [[3 - Encounter with a robot]]
“Like what you see?”

‘*Damn, get yourself together, Denter, at your age you shouldn´t start blushing that easily.’*

“Listen to that inner voice of yours, Denter.”

His redness turned to purple.

“You’re just being a healthy grown-up man, Liam, I’m not holding this against you - I consider it more a compliment. But let’s look forward, see how we are going to tackle this one”.

“I would start by disabling the track and trace of this cab and then override the navigation. They’ll be looking for us on every Upper highway, let’s go find the lower levels. And then, it might be an idea to explain how you got into that room without me noticing it”.

“I was already in the room before you were put in there, the blend-in feature that comes with the model GH - H stands for high-end - is pretty exclusive, only 3 devices have been equipped with it. That should answer your last remark. Good thinking, avoiding the 3 upper levels, if there’s a roadblock, it will be on those levels because all navigation systems are set to use those highways rather than the lower-level ones. But our next move is not going to be so easy - we should try to get to the Hyper. With it, we could be in Lower East Pannodis - that’s still New York in your language, I think - by 3 pm, depending on the available seats”.

“I’m not so fond of the term “device” if you don’t mind me saying so. But glad you agree with me. And I follow you on the Hyper - but I would need to reveal my ID. And that is not exactly what I’m looking forward to”.

“Remember me altering your tracking device just before we jumped into the elevator?“

She waited for Liam to nod, then continued: “I also altered your ID in the same move”.

The cab changed levels, went down one, changed lanes, and took another level down. In the caverns of Latrait, formerly L.A., they continued their journey in complete silence until the car stopped in front of a worn-out office building. The windows looked as if there was ... at least, it seemed to be glass in them, in ... hell, yeah, that were wooden frames. Gosh, back to the 20s, suddenly.

Margo stepped out, looked around, and gave Liam a short sign of her hand to follow her into the building. He turned his head, the taxi was already gone. No sound down here, and a penetrating smell of a totally eclipsed past, like the smell of a room where doors and windows had been closed for years and in which dust had been kept for years. It wasn’t an exact comparison, but it sure came close. Liam followed Margo five floors down and they found themselves in front of a hatch, that didn’t even try to look like a door. It had a handle, sunk into its cover, like the closet of a firehose. As a matter of fact, it completely looked like one of those compartments architects had to foresee - nowadays, AI had taken over all aspects of fire prevention.

When the hatch opened, it revealed yet another stair down. “You go first, this leads to the back office of the Hyper station Centre East, we’ll be as close to the departure platform as possible. When you get there, if there’s someone controlling, act normal, your wrist-ID won’t reveal your true identity, remember?”

▶ [[5 -  Saltwick, 2 pm]]