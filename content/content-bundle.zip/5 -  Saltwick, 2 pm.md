# 5 -  Saltwick, 2 pm
◀ [[4 - Going down some levels]]
“Come on, Jaxon, you already own Lower East Pannodis, you have a palace that is comparable to Kershaw’s Brivey Palace and yet, you don’t feel like it is enough.”

“No, it is not and it never will be enough. For a street kid like myself, it’s important to prove myself over and over again.”

“By murdering human wallets? You really haven’t outgrown your street fighter level, if you don’t mind me saying so.“

“No, I don’t, anyone else would be playing with her life, but not you, Candice, I even keep you around to have at least one opponent worthy of me.”

“Now you’re talking. now I hear the Jaxon I know: arrogant, patronizing, and insufferable. And, foremost, despicable. You’re really a disgusting character, did you ever come to that conclusion with your louse brain? If you jump, you don’t even reach my ankles. I’m out of here - and, by the way, if you want to kill that human wallet, be my guest, by all means, ruin the fraction of the reputation you had left so that nobody will ever trust you again. In case you’d found someone who still did.“

“No, they don’t trust me - and I don’t need their trust, I need their business, their money, and their loyalty. Even if that has been enforced by fear.”

“You know what happened to that other swine, that Russian who - back in the lethal 20’s - thought he could reign based on fear. Ukraine has beaten the shit out of him.”

“Ukraine and twelve other countries.”

“Still, the result was the same, wasn’t it?”

“OK, you’ve got a point. And by the way, I loved the image of that moron at the time of his arrest, and the title on Time Magazine. ‘Putin put in custody’. Strange we never got to know where they put him away.”

“They probably never did, he just died the most painful death possible. Once he was handed over to Zelenski’s boys, his chances to keep his balls were close to zero percent. He most probably had to eat them”.

“I love it when you talk dirty to me.“

“Go fuck yourself, Jaxon, because you know you’ll never be man enough to fuck a girl like me. And stay tuned for a moment, will you? I said it doesn't even come close to a brilliant plan to waste the human wallet. Think of an alternative - or you’ll end up without the opponent that’s worthy of you”.

 “Are you threatening me?”

“I might - but be careful what you wish for. I never threaten anyone without executing my threats”.

▶ [[6 - Brivey Palace, 202 pm]]
