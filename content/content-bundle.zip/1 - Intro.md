# 1 - Intro
◀ [[0 - ToC]]
**2042 – The Huxton Empire**
> Since the lethal ’20s, life had never gone back to normal again. Covid-19 was a walk in the park compared to the outbreak of the 4 Viruses. Besides killing one-third of the world population, they also caused the economic system to collapse, leaving only one winner: Kershaw, former president of the US. 
> Numerous theories about the way he gathered his wealth and power circulate, but were all brutally suppressed. His reign was marked by terror, fear and violence.
> The economic life and infrastructure was destroyed unless it offered advantages to Kershaw and his family. His daughter, who took over the power after her father died, is even more ruthless and has murdered more opponents in 1 year than her father did in 20.
>  In these very uncertain times, human couriers deliver payments to bypass the network, which is hacked on an hourly basis.*

In the largest of the numerous office buildings in the Latrait Business District of the Huxton Empire, Thorben got slightly irritated with his father.

“I know that, back in the ’20s, you already were in your forties. And I do know that Bitcoin was the only notable crypto at that time and that it had just started to emerge. I also know that it is not a given for elderly like you to calculate in ZIPx, but to make myself perfectly clear: what our Human Wallet will have in his head is enough to buy half of what used to be Manhattan. So I think it does make sense to get him a baby-sit”.

“But why on earth the Xe4S?? They cost a fortune and it’ll have to be re-programmed after this trip”.

“Because we’ll know for sure that our money will be safely handed over to Jaxon before the deadline. Meaning you and I will stay alive. Meaning we will have no further business with Jaxon anymore. Ever. Could you please for once think practically? Not just for me, and not in the least for you, dad, but certainly for the sake of your grandson.”

Pete knew that Thorben was right, but was still a bit reluctant to pay the price of a 4-bedroom apartment with a view on Huxton Gardens for a robot that would be useless after the trip. Unless it was reprogrammed. If it came back at all, that was. And if the Human Wallet wouldn’t make it back, well... Pete couldn’t care less, he paid him to get the currency implanted in his hippocampus and have it removed by Jaxon. Because Jaxon was the only person on earth who owned the indispensable asymmetric 2048-bits decryption key that made AES look like a toy for toddlers.

Hackers would just love to play and hack the net, intercepting the cargo. Sending a carrier implied the threat of those other pirates, who would prefer to assault the carrier, just for the sport of it. This particular carrier would be carrying 4% of the circulating supply of the mainstream crypto. 4% of 62.5 billion ZIPx is an awful lot of money, attracting all sorts of criminals, warlords, assassins, and other cuties. Even if none of them would be able to decrypt the nanochip in a million years. 

So, Pete and Thorben opted for a Human Wallet to deliver the cash in Saltwick, where Jaxon Reyes ruled. He was as ruthless as the Emperor, Kershaw, and there was no guarantee that the hardware (or HW, or Human Wallet) would make it back to Latrait. Even if accompanied by the top-notch robot, or even better: a humanoid, not distinguishable at all from humans. Lamere & Hinckson, the honorable manufacturers, had come a very, very long way and had indeed delivered perfection.

▶ [[2 - Kagu is worried]]