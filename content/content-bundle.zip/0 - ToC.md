# 0 - ToC
[[1 - Intro]]
[[2 - Kagu is worried]]
[[3 - Encounter with a robot]]
[[4 - Going down some levels]]
[[5 -  Saltwick, 2 pm]]
[[6 - Brivey Palace, 202 pm]]