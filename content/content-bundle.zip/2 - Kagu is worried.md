# 2 - Kagu is worried
◀ [[1 - Intro]]
That same afternoon, somewhere in the Newdales, Liam Denter (Human Wallet permit 25B36) looked his mother in the eyes and said very seriously: “I know I promised, mom, but this one could not only get you out of that wheelchair, but it’ll also make sure we can both retire for good, without having to worry about the rent for the rest of our lives”.

“If there’s so much money involved, it’s most certainly a very tricky job. I’ll probably die of anxiety”.

“Will you stop worrying, silly? They even provide me with a robot for protection”.

“Well, now that’s reassuring – clients never pay for their Wallet’s protection. If this one does, it is not just a tricky assignment but your life’s most certainly in danger. Who is it from, for how much, and to whom do you have to transport?”

“You know I cannot discuss any of those details – the Dark Finance's ways should remain inscrutable. But rest assured, mother, we’ll be fine. I’ll do the job, get back to my clients' place with his receipt and his robot, come back here and make that appointment for your brain surgery that will get you in shape again.”

“Promise me you’ll be careful, son.”

“You know there’s not a lot I can do about it, mother, you’ve been there, done that – Wallets have no influence on clients or recipients and certainly not on the expertise of the implanters. But then again, science has evolved and nowadays a mistake like the one that happened to you is most unlikely. If I’m not mistaken, Amaya Burns would be the implanter. And she is considered to be the best of the best”.

“Apart from her tattoo of Kershaw’s first name on her lower back”.

Liam grinned, knowing that they finally were entering the lighter part of the conversation:

“What’s wrong with a tattoo of the late Emperor, mother? And how do you know it’s on her lower back?”

“A little bird told me”.

'And that little bird happens to be a kagu, I guess'?

This time, it was Alyssa who grinned. Sure, her real name was Denter born Nelson, but on the Deep Net, her user name was Kagu, the bird also known as ‘ghost of the forest’, the New Caledonian emblem.

“When’s that car picking you up?”

“In five,… no,… three,” he said, after a quick look at his wrist-display.

“Shouldn’t you be getting ready then? You know they don’t even wait for 10 seconds”.

“Guess you’re right I’ll see you next week, behave meanwhile, will you?”

“That’s my line, Denter. Which reminds me that you are a son of your father and you have no right to die on me also, *capisce*?”

“*Capisco, Principessa”*.

He stepped outside and the newest model of pickup cabs drove silently up to where he was standing. A minimal movement of his wrist towards the door identified him and unlocked the door. Once he sat down, the cab headed straight for the Latrait Health Care center, as it had been entered as his destination at reservation. Even if it was illegal, Liam switched off the Huxton Channel, so he could at least try to enjoy the ride.

From the Newdales to the Business District, there were a couple of views worth looking at, especially because of the vastness of those views, instigating an illusion of freedom.

The trip took the cab exactly 24 minutes, leaving Liam 6 minutes to sign out of the car and walk to the entrance of that huge glass building. The very human-looking robot at the reception desk told him he was expected in exactly 3 minutes on the 56th floor and that he should take elevator C-2 to get to treatment room 56-3. From that moment onwards, Liam knew he was being monitored and that didn’t help to keep his nerve down.

Okay, maybe it was just because of the chip that was due to be implanted in his brain. Always at this point, Liam realized that, although it wasn’t a very invasive surgery, it was still brain surgery.

“25B36, I presume?”

“Yes, doctor Burns – and no, I haven’t got a cold, wasn’t infected with the latest 3 viruses and yes, this is all blockchain-certified information, but I know you have to ask”.

“Not your first, apparently?”

“Indeed, but most likely to be my last”.

“Well, if that is what you want, I hope you can stick to it. I do make a living out of this, but it is getting harder and harder for me to not see the health impact of these interventions”.

Liam chuckled “Go tell my mother”, causing Amaya Burns to look more carefully at him.

“Alyssa Nelson’s son, no?”

“Uhu, Can we get on with it?”

“Still nervous after all these years? Relax, I know what I’m doing.”

Liam laid down on his stomach, hardly noticed the anesthetic injection, and came to his senses 25 minutes later, with 2.5 billion ZIPx encapsulated in his hippocampus.

▶ [[3 - Encounter with a robot]]