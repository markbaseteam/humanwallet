# 6 - Brivey Palace, 2:02 pm
◀ [[5 -  Saltwick, 2 pm]]

Slemor Kershaw, the empress, was bored. Again. She did need those murders, with lots of blood, to at least get some glimpse of excitement.